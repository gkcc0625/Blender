#!/bin/bash

python3.7 setup.py build_ext --inplace
mv nodepreview_worker.*.so ..
rm -r ./build
