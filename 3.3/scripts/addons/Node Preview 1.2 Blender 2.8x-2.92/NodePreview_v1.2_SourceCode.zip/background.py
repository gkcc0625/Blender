#
#     This file is part of NodePreview.
#     Copyright (C) 2021 Simon Wendsche
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.

import bpy

import threading
import queue
from multiprocessing.connection import Client
from array import array
from time import time, perf_counter

from . import THUMB_CHANNEL_COUNT
from . import messages
from . import nodepreview_worker


jobs = queue.LifoQueue()
results = queue.SimpleQueue()
node_timestamps = {}
free_requested = False
stop_requested = False


def free():
    """ Must be executed from main thread! """
    print("Background: Freeing ressources")
    images = bpy.data.images
    for image in images:
        images.remove(image)

    node_timestamps.clear()


def watcher_func(wakeup_condition, port, authkey):
    with Client(("localhost", port), authkey=authkey) as connection:
        try:
            connection.send((messages.BACKGROUND_PROCESS_READY, None))

            while True:
                # print("Listener: polling")
                if connection.poll(timeout=0.05):
                    try:
                        msg = connection.recv()
                        tag, data = msg
                    except EOFError as error:
                        print(error)
                        tag = messages.STOP

                    if tag == messages.NEW_JOB:
                        with wakeup_condition:
                            jobs.put(data)
                            wakeup_condition.notify()
                    elif tag == messages.FREE_RESSOURCES:
                        with wakeup_condition:
                            global free_requested
                            free_requested = True
                            wakeup_condition.notify()
                    elif tag == messages.STOP:
                        print("Listener: Stopping")
                        break

                while not results.empty():
                    try:
                        result = results.get(block=False)
                        connection.send((messages.JOB_DONE, result))
                    except queue.Empty:
                        pass
        except ConnectionResetError as error:
            print(error)

    with wakeup_condition:
        # No lock required because this operation is atomic in CPython
        global stop_requested
        stop_requested = True
        wakeup_condition.notify()


def run(port, authkey):
    global free_requested

    wakeup_condition = threading.Condition()

    watcher = threading.Thread(target=watcher_func, args=(wakeup_condition, port, authkey))
    watcher.start()

    while True:
        with wakeup_condition:
            while jobs.empty() and not stop_requested and not free_requested:
                wakeup_condition.wait()

        if stop_requested:
            break

        if free_requested:
            free()
            free_requested = False

        try:
            job = jobs.get(block=False)

            start = perf_counter()
            success, result = do(job)

            if success:
                elapsed = perf_counter() - start
                print("job done in %.3f s" % elapsed)
                print("jobs remaining:", jobs.qsize())

                results.put(result)
        except queue.Empty:
            continue

    watcher.join()


def do(job):
    (
        node_key,
        script,
        images_to_load,
        images_to_link,
        display_blend_abspath,
        thumb_path,
        thumb_resolution,
        timestamp
    ) = job

    try:
        last_timestamp = node_timestamps[node_key]
        if timestamp < last_timestamp:
            # Job is outdated, ignore it (a newer job was already completed)
            # print("Ignoring outdated job:", node_key)
            return False, None
    except KeyError:
        pass

    if display_blend_abspath:  # Can't link if .blend was not saved yet
        new_images_to_link = images_to_link - set(bpy.data.images.keys())
        if new_images_to_link:
            print("linking images:", new_images_to_link)
            with bpy.data.libraries.load(display_blend_abspath, link=True) as (data_from, data_to):
                data_to.images = [name for name in data_from.images if name in new_images_to_link]

    for image_name, abspath in images_to_load:
        if image_name not in bpy.data.images:
            print("loading image:", image_name)

            # What I would like to do, but doesn't work due to a bug in Blender:
            # (https://developer.blender.org/T85772)
            # image = bpy_extras.image_utils.load_image(abspath, check_existing=True, force_reload=False)
            # # Calculate correct width and height
            # image.scale(width, height)

            # Blender images are always created with 4 channels
            max_size = thumb_resolution
            try:
                pixels, width, height = nodepreview_worker.load_image_scaled(abspath, max_size)
                image = bpy.data.images.new(image_name, width, height, alpha=True,
                                            float_buffer=True, is_data=False)
                if hasattr(image.pixels, "foreach_set"):
                    image.pixels.foreach_set(pixels)
                else:
                    image.pixels[:] = pixels
            except ValueError as error:
                # Fallback for ValueError from nodepreview_worker.load_image_scaled()
                # This happens if the worker doesn't support the image format. 
                # We use Blender to load the image instead in that case.
                print(error)
                width = max_size
                height = max_size
                image = bpy.data.images.new(image_name, width, height, alpha=True,
                                            float_buffer=True, is_data=False)

            assert image.name == image_name

    node_tree = bpy.data.materials['Material'].node_tree
    starting_nodes = [node.name for node in node_tree.nodes]
    error_message = ""
    full_error_log = ""

    try:
        exec(script)
    except Exception as error:
        error_message = str(error)
        
        import traceback
        full_error_log += traceback.format_exc()

        full_error_log += "\nScript: --------------------\n"
        for i, line in enumerate(script.split("\n")):
            full_error_log += str(i + 1) + " \t" + line + "\n"
        full_error_log += "----------------------------"

        # Red surface
        node_tree = bpy.data.materials['Material'].node_tree
        output_node = node_tree.nodes['Material Output']
        error_node = node_tree.nodes.new("ShaderNodeEmission")
        error_node.inputs[0].default_value = [1, 0, 0, 1]
        node_tree.links.new(error_node.outputs[0], output_node.inputs[0])

    settings = bpy.context.scene.render
    settings.filepath = thumb_path
    settings.resolution_x = thumb_resolution
    settings.resolution_y = thumb_resolution
    bpy.ops.render.render(write_still=True)
    result_array = array("b", [0]) * (thumb_resolution * thumb_resolution * THUMB_CHANNEL_COUNT)
    # Could also load the result into a Blender image (overwrite always the same), to avoid using a C++ module
    nodepreview_worker.load_image_array(result_array, thumb_path)

    for node in node_tree.nodes:
        if node.name not in starting_nodes:
            node_tree.nodes.remove(node)

    # Delete all node groups
    for node_tree in bpy.data.node_groups[:]:
        bpy.data.node_groups.remove(node_tree, do_unlink=True, do_id_user=True, do_ui_user=True)

    node_timestamps[node_key] = time()
    print("job done for node_key:", node_key)
    return True, (node_key, result_array, thumb_resolution, timestamp, error_message, full_error_log)
