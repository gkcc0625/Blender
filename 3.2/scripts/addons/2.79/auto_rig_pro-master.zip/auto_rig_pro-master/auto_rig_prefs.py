import bpy



class arp_addon_preferences(bpy.types.AddonPreferences):
	bl_idname = __package__	

	def draw(self, context):		
		col = self.layout.column(align=True)
		col.prop(context.scene, "arp_debug_mode")
		



def register():
	bpy.types.Scene.arp_debug_mode = bpy.props.BoolProperty(name="Debug Mode", default = False, description = "Run the addon in debug mode (should be enabled only for debugging purposes, not recommended for a normal usage)")
	
def unregister():
	del bpy.types.Scene.arp_debug_mode
