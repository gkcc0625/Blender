#
#     This file is part of NodePreview.
#     Copyright (C) 2021 Simon Wendsche
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.

import bpy
from bpy.app.handlers import persistent
from bpy.types import SpaceImageEditor, SpaceNodeEditor, AddonPreferences
import bgl
import blf
import gpu
from gpu_extras.batch import batch_for_shader

from time import time
from math import sqrt
import os
import platform
from glob import glob
import tempfile
import shutil
import subprocess
import threading
from multiprocessing import current_process
from multiprocessing.connection import Listener, Connection
from typing import Optional
import base64
import re
import queue

from . import (addon_name, THUMB_CHANNEL_COUNT, force_node_editor_draw, get_ignore_scale,
               needs_linking, UnsupportedNodeException)
from . import messages, node_converter, scene_converter

current_dir = os.path.dirname(os.path.realpath(__file__))

if platform.system() not in {"Windows", "Linux", "Darwin"}:
    raise Exception("\n\nUnsupported platform:", platform.system())

try:
    from . import nodepreview_worker
except ImportError as error:
    msg = ""
    if platform.system() == "Windows":
        msg = ("\n\nYou have to install the following: https://aka.ms/vs/15/release/vc_redist.x64.exe\n"
               "Check the doc.txt file for more information about how to install this addon.")
    # Raise from None to suppress the unhelpful
    # "during handling of the above exception, ..."
    raise Exception(msg + "\n\nImportError: %s" % error) from None


class WatcherThread(threading.Thread):
    def __init__(self,  *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._stop_event = threading.Event()

    def stop(self):
        self._stop_event.set()

    def stopped(self):
        return self._stop_event.is_set()

    def run(self):
        while not self.stopped():
            if connection.poll(timeout=0.05):
                msg = connection.recv()
                tag, data = msg

                if tag == messages.BACKGROUND_PROCESS_READY:
                    global background_process_ready
                    background_process_ready = True
                    # Force one refresh to render all nodes that are currently visible
                    force_node_editor_draw()
                elif tag == messages.JOB_DONE:
                    node_key, result_array, thumb_resolution, job_timestamp, error_message, full_error_log = data
                    
                    if full_error_log:
                        addon_print(full_error_log)

                    try:
                        # The old thumbnail will be deleted. We need to free its OpenGL texture in the main thread later.
                        old_texture_id = thumbnails[node_key].texture_id
                        if old_texture_id != 0:
                            texture_ids_to_delete.put(old_texture_id)
                    except KeyError:
                        pass

                    thumb = Thumbnail()
                    thumb.buffer = bgl.Buffer(bgl.GL_BYTE, [len(result_array)], result_array)
                    thumb.width = thumb_resolution
                    thumb.height = thumb_resolution
                    thumb.channel_count = THUMB_CHANNEL_COUNT
                    thumb.text = error_message

                    thumbnails[node_key] = thumb

                    try:
                        last_timestamp = cached_nodes[node_key][1]
                        if job_timestamp < last_timestamp:
                            # Force re-sending the job if the last job didn't go through
                            del cached_nodes[node_key]
                    except KeyError:
                        pass

                    force_node_editor_draw()


handle = None  # Draw handler
thumbnails = {}  # filepath : Thumbnail
texture_ids_to_delete = queue.Queue()
cached_nodes = {}  # node_key : hash(node_script), timestamp
# Output directory where rendered thumbnails are saved by our Blender sub-process
temp_dir = os.path.join(tempfile.gettempdir(), f"BlenderNodePreview_{os.getpid()}")
TEMP_DIR_REGEX_PATTERN = r"BlenderNodePreview_[0-9]+"

background_process_ready = False
background_process: Optional[subprocess.Popen] = None
listener: Optional[Listener] = None
connection: Optional[Connection] = None
watcher_thread: Optional[WatcherThread] = None


SUPPORTED_NODE_TREE = "ShaderNodeTree"
UNSUPPORTED_NODES = {
    "ShaderNodeShaderToRGB",
    "NodeReroute",
    "ShaderNodeHoldout",  # Makes no sense to render a black thumbnail every time
    "ShaderNodeEeveeSpecular",
    "ShaderNodeAttribute",
    "NodeGroupInput",
    "NodeGroupOutput",
}
NODES_NEEDING_MORE_SAMPLES = {
    "ShaderNodeSubsurfaceScattering",
    "ShaderNodeVolumeScatter",
    "ShaderNodeVolumePrincipled",
    "ShaderNodeBevel",
    "ShaderNodeMixShader",
    "ShaderNodeAddShader",
}
# Above these thresholds, procedural textures become too fine-grained for the preview (at default texture mapping)
SCALE_HELP_THRESHOLDS = {
    "ShaderNodeTexBrick": 11,
    "ShaderNodeTexChecker": 35,
    "ShaderNodeTexMagic": 16,
    "ShaderNodeTexMusgrave": 50,
    "ShaderNodeTexNoise": 40,
    "ShaderNodeTexWave": 11,
    "ShaderNodeTexVoronoi": 30,
}
NULL = 0

if not bpy.app.background:
    with open(os.path.join(current_dir, "shaders", "thumbnail_vert.glsl")) as vert:
        with open(os.path.join(current_dir, "shaders", "thumbnail_frag.glsl")) as frag:
            shader = gpu.types.GPUShader(vert.read(), frag.read())


class Thumbnail:
    def __init__(self):
        self.texture_id = 0
        self.texture_initialized = False
        self.buffer = None
        self.width = -1
        self.height = -1
        self.channel_count = -1
        self.text = ""

    def load_texture(self):
        """Has to be called from the main thread!"""
        texture = bgl.Buffer(bgl.GL_INT, 1)
        bgl.glGenTextures(1, texture)
        self.texture_id = texture[0]

        bgl.glActiveTexture(bgl.GL_TEXTURE0)
        bgl.glBindTexture(bgl.GL_TEXTURE_2D, self.texture_id)
        # Note: I always use bgl.GL_RGBA8 and bgl.GL_RGBA (4 channels).
        # According to the OpenGL specification, most graphics drivers transform anything
        # with less channels than 4 into GL_RGBA8. Unfortunately, this conversion seems
        # to be buggy (e.g. on my Nvidia driver), so I'm not using less channels than 4,
        # even though I would like to (to save memory).
        bgl.glTexImage2D(bgl.GL_TEXTURE_2D, 0, bgl.GL_RGBA8, self.width, self.height,
                         0, bgl.GL_RGBA, bgl.GL_BYTE, self.buffer)

        edge_mode = bgl.GL_CLAMP_TO_EDGE
        bgl.glTexParameteri(bgl.GL_TEXTURE_2D, bgl.GL_TEXTURE_WRAP_S, edge_mode)
        bgl.glTexParameteri(bgl.GL_TEXTURE_2D, bgl.GL_TEXTURE_WRAP_T, edge_mode)

        interpolation_mode = bgl.GL_LINEAR
        bgl.glTexParameteri(bgl.GL_TEXTURE_2D, bgl.GL_TEXTURE_MIN_FILTER, interpolation_mode)
        bgl.glTexParameteri(bgl.GL_TEXTURE_2D, bgl.GL_TEXTURE_MAG_FILTER, interpolation_mode)

        bgl.glBindTexture(bgl.GL_TEXTURE_2D, NULL)
        self.texture_initialized = True

        err = bgl.glGetError()
        if err != bgl.GL_NO_ERROR:
            addon_print("GL Error during texture initialization:", err)

    def draw(self, bottom_left, bottom_right, top_right, top_left, scaled_zoom):
        bgl.glActiveTexture(bgl.GL_TEXTURE0)
        bgl.glBindTexture(bgl.GL_TEXTURE_2D, self.texture_id)

        shader.bind()
        shader.uniform_int("image", 0)
        shader.uniform_int("gamma_correct", bpy.app.version >= (2, 91, 0))

        batch = batch_for_shader(
            shader, 'TRI_FAN',
            {
                "pos": (bottom_left, bottom_right, top_right, top_left),
                "texCoord": ((0, 1), (1, 1), (1, 0), (0, 0)),  # Note: Mirrored along y axis
            },
        )
        batch.draw(shader)

        self._draw_text(bottom_left, scaled_zoom)

        err = bgl.glGetError()
        if err != bgl.GL_NO_ERROR:
            addon_print("GL Error during draw:", err)

    def _draw_text(self, position, scaled_zoom):
        if not self.text:
            return

        draw_text(self.text, position, 10, scaled_zoom)


def draw_text(text, position, font_size, scaled_zoom):
    FONT_ID = 0
    FONT_DPI = 72
    text_pos_x, text_pos_y = position
    blf.position(FONT_ID, text_pos_x, text_pos_y, 0)
    blf.size(FONT_ID, round(font_size * scaled_zoom), FONT_DPI)
    blf.draw(FONT_ID, text)


def delete_old_textures_if_necessary():
    count = texture_ids_to_delete.qsize()
    if count > 40:  # Arbitrary threshold
        texture_ids = bgl.Buffer(bgl.GL_INT, [count])
        for i in range(count):
            texture_ids[i] = texture_ids_to_delete.get(block=True)
        bgl.glDeleteTextures(count, texture_ids)


def addon_print(*args, **kwargs):
    print("[NodePreview]", *args, **kwargs)


def view_to_region_scaled(context, x, y, clip=True):
    ui_scale = context.preferences.system.ui_scale
    return context.region.view2d.view_to_region(x * ui_scale, y * ui_scale, clip=clip)


def get_region_zoom(context):
    test_length = 1000
    x0, y0 = context.region.view2d.view_to_region(0, 0, clip=False)
    x1, y1 = context.region.view2d.view_to_region(test_length, test_length, clip=False)
    xl = x1 - x0
    yl = y1 - y0
    return sqrt(xl**2 + yl**2) / test_length


def needs_more_than_1_sample(node):
    bl_idname = node.bl_idname

    if node.bl_idname == "ShaderNodeGroup" and node.node_tree:
        for subnode in node.node_tree.nodes:
            if needs_more_than_1_sample(subnode):
                return True

    if bl_idname == "ShaderNodeBsdfTransparent":
        return False

    if bl_idname == "ShaderNodeBsdfDiffuse" and node.inputs["Normal"].is_linked:
        return True

    if bl_idname in {"ShaderNodeBsdfDiffuse", "ShaderNodeBsdfGlossy"}:
        roughness_input = node.inputs["Roughness"]
        # At roughness = 0, there's no noise with 1 sample
        return roughness_input.is_linked or roughness_input.default_value > 0

    return (bl_idname.startswith("ShaderNodeBsdf")
            or bl_idname in NODES_NEEDING_MORE_SAMPLES)


def is_node_supported(node):
    if len(node.outputs) == 0:
        return False

    return node.bl_idname not in UNSUPPORTED_NODES


def to_valid_filename(name):
    return base64.urlsafe_b64encode(name.encode("UTF-8")).decode("UTF-8")


def handler():
    # from time import perf_counter
    # __start = perf_counter()

    if not background_process_ready:
        return

    context = bpy.context

    if context.space_data.tree_type != SUPPORTED_NODE_TREE:
        return

    if not context.space_data.path:
        return

    # Path contains a chain of nested node trees, the last one is the currently active one
    node_tree = context.space_data.path[-1].node_tree
    if not node_tree:
        return

    if not node_converter.node_attributes_cache:
        node_converter.build_node_attributes_cache()

    area = context.area
    ui_scale = context.preferences.system.ui_scale
    zoom = get_region_zoom(context)
    scaled_zoom = zoom * ui_scale
    preferences = context.preferences.addons[addon_name].preferences
    thumb_scale = preferences.thumb_scale / 100
    thumb_resolution = preferences.thumb_resolution

    # Sort nodes
    def get_dependent_nodes(node):
        # Loop through nodes to the right
        for output in node.outputs:
            for link in output.links:
                yield link.to_node
    sorted_nodes = node_converter.sort_topologically(node_tree.nodes, get_dependent_nodes)
    node_scripts_cache = {}

    bgl.glEnable(bgl.GL_BLEND)
    bgl.glBlendFunc(bgl.GL_SRC_ALPHA, bgl.GL_ONE_MINUS_SRC_ALPHA)
    bgl.glBlendEquation(bgl.GL_FUNC_ADD)

    group_script, group_images_to_load, group_images_to_link, group_hashes = node_converter.node_groups_to_script(sorted_nodes)
    material = context.space_data.id

    jobs_to_send = []

    for node in sorted_nodes:
        if not is_node_supported(node):
            continue

        try:
            script_header = "import bpy; import mathutils"
            node_script, images_to_load, images_to_link = node_converter.node_to_script(node, node_tree, material, node_scripts_cache, group_hashes, preferences)
            scene_script = scene_converter.scene_to_script(context, needs_more_than_1_sample(node), thumb_resolution)
            script_hash = hash(node_script)
            node_key = node_converter.make_node_key(node, node_tree, material)

            if node_key not in cached_nodes or cached_nodes[node_key][0] != script_hash:
                timestamp = time()
                thumb_path = os.path.join(temp_dir, to_valid_filename(node_key) + ".png")
                job = (
                    node_key,
                    "\n".join((script_header, group_script, node_script, scene_script)),
                    images_to_load | group_images_to_load,
                    images_to_link | group_images_to_link,
                    bpy.path.abspath(bpy.data.filepath),
                    thumb_path,
                    thumb_resolution,
                    timestamp,
                )
                jobs_to_send.append(job)
                cached_nodes[node_key] = script_hash, timestamp
        except UnsupportedNodeException:
            continue

        location = node.location.copy()
        n = node
        while n.parent:
            # Take (possibly nested) frames into account
            location += n.parent.location
            n = n.parent

        topleft_x, topleft_y = view_to_region_scaled(context, *location, clip=False)
        # x1 is the top right of the node
        topright_x, _ = view_to_region_scaled(context, location[0] + node.width, 0, clip=False)
        node_width = (topright_x - topleft_x)

        BASE_WIDTH = 150
        size = BASE_WIDTH * scaled_zoom * thumb_scale
        offset_x = (node_width - size) / 2 + 1  # For some reason we are one pixel too far to the left, thus +1
        offset_y = 5 * scaled_zoom * thumb_scale  # Some vertical offset from the node

        bottom_left = (topleft_x + offset_x, topleft_y + offset_y)
        bottom_right = (topleft_x + offset_x + size, topleft_y + offset_y)
        top_right = (topleft_x + offset_x + size, topleft_y + offset_y + size)
        top_left = (topleft_x + offset_x, topleft_y + offset_y + size)

        # Don't draw the texture when it is out of bounds
        if bottom_right[0] < 0 or bottom_left[0] > area.width or top_left[1] < 0 or bottom_left[1] > area.height:
            continue

        try:
            thumb = thumbnails[node_key]
        except KeyError:
            thumb = None

        if thumb is None or thumb.buffer is None:
            continue

        if not thumb.texture_initialized:
            thumb.load_texture()

        thumb.draw(bottom_left, bottom_right, top_right, top_left, scaled_zoom)

        if preferences.show_help and "Scale" in node.inputs and not get_ignore_scale(node):
            try:
                threshold = SCALE_HELP_THRESHOLDS[node.bl_idname]
                if node.inputs["Scale"].is_linked or node.inputs["Scale"].default_value > threshold:
                    x = topleft_x
                    y = top_left[1] + 3 * scaled_zoom
                    draw_text("Scale can be ignored", (x, y + 10 * scaled_zoom), 10, scaled_zoom)
                    draw_text("with Ctrl+Shift+i", (x, y), 10, scaled_zoom)
            except KeyError:
                # Node doesn't have a known scale threshold, don't show the help message
                pass

        image = getattr(node, "image", None)
        if image and (needs_linking(image) and not bpy.data.filepath):
            x = topleft_x
            y = top_left[1] + 3 * scaled_zoom
            draw_text("Save .blend to render preview", (x, y), 10, scaled_zoom)

    bgl.glBindTexture(bgl.GL_TEXTURE_2D, NULL)
    bgl.glDisable(bgl.GL_BLEND)

    # Send jobs in reversed order so the leftmost node (which was edited) is rendered first for fast feedback
    for job in reversed(jobs_to_send):
        connection.send((messages.NEW_JOB, job))

    delete_old_textures_if_necessary()

    # print("draw handler took %.3f s" % (perf_counter() - __start))


def free():
    cached_nodes.clear()

    texture_count = len(thumbnails)

    if texture_count > 0:
        texture_ids = bgl.Buffer(bgl.GL_INT, [texture_count])
        for i, thumb in enumerate(thumbnails.values()):
            texture_ids[i] = thumb.texture_id
        bgl.glDeleteTextures(texture_count, texture_ids)
        thumbnails.clear()


def stop_threads_and_process():
    global watcher_thread, connection, listener, background_process, background_process_ready
    background_process_ready = False

    if watcher_thread:
        watcher_thread.stop()
        watcher_thread.join()
        watcher_thread = None

    if connection:
        connection.send((messages.STOP, None))
        connection.close()
        connection = None

    if listener:
        listener.close()
        listener = None

    if background_process:
        try:
            background_process.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            background_process.kill()
            background_process.communicate()
            addon_print("Background Process was killed after timeout.")

        background_process = None


def clean_temp_dir():
    os_temp_dir = os.path.dirname(temp_dir)
    addon_temp_dirs = [os.path.join(os_temp_dir, name) for name in os.listdir(os_temp_dir)
                       if re.match(TEMP_DIR_REGEX_PATTERN, name)]

    for path in addon_temp_dirs:
        try:
            # Only delete old temp dirs. Recent ones might still be in use by another Blender process.
            seconds_since_last_modification = time() - os.path.getmtime(path)
            if seconds_since_last_modification > 60 * 60 * 24:
                shutil.rmtree(path)
        except Exception as error:
            addon_print("Could not delete temp dir:", path)
            addon_print(error)


@persistent
def load_pre(_=None):
    free()
    # Delete images in the background process to free up RAM
    if background_process_ready:
        connection.send((messages.FREE_RESSOURCES, None))


def exit_callback():
    stop_threads_and_process()
    free()
    clean_temp_dir()


def start_background_process():
    authkey = current_process().authkey
    global listener

    port = 6000
    while port < 10000:
        try:
            listener = Listener(('localhost', port), authkey=authkey)
            break
        except OSError as error:
            if ((platform.system() == "Windows" and error.errno == 10048)
                or (platform.system() == "Linux" and error.errno == 98)):
                # Windows: [WinError 10048] Only one usage of each socket address (protocol/network address/port) is normally permitted
                # Linux: [Errno 98] Address already in use
                port += 1
            else:
                raise

    global background_process
    process_args = [
        bpy.app.binary_path,
        "--factory-startup",
        # The Images as Planes addon is needed so bpy_extras contains the image_utils submodule
        "--addons", f"{addon_name},io_import_images_as_planes",
        "-b",  # Run in background without UI
        os.path.join(current_dir, "data", "previewscene.blend"),
        "--python-expr", f"import {addon_name}; {addon_name}.background.run({port}, {authkey})",
    ]
    env_copy = os.environ.copy()
    env_copy["BLENDER_USER_SCRIPTS"] = bpy.context.preferences.filepaths.script_directory
    silent = True
    if silent:
        background_process = subprocess.Popen(process_args, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL, env=env_copy)
    else:
        background_process = subprocess.Popen(process_args, env=env_copy)

    global connection
    connection = listener.accept()

    global watcher_thread
    watcher_thread = WatcherThread()
    watcher_thread.setDaemon(True)
    watcher_thread.start()


def display_register():
    import atexit
    # Make sure we only register the callback once
    atexit.unregister(exit_callback)
    atexit.register(exit_callback)

    handler_args = ()
    global handle
    # Note: not using "BACKDROP" because the thumbnails would be behind frames in that mode
    handle = SpaceNodeEditor.draw_handler_add(handler, handler_args, "WINDOW", "POST_PIXEL")

    bpy.app.handlers.load_pre.append(load_pre)

    process_starter = threading.Thread(target=start_background_process)
    # In case the background process throws an exception, the process_starter thread could get stuck
    # on listener.accept(). Enable the daemon flag to make sure the Blender process doesn't hang after
    # quit when this happens.
    process_starter.setDaemon(True)
    process_starter.start()


def display_unregister():
    SpaceNodeEditor.draw_handler_remove(handle, "WINDOW")
    bpy.app.handlers.load_pre.remove(load_pre)
    free()
    stop_threads_and_process()
