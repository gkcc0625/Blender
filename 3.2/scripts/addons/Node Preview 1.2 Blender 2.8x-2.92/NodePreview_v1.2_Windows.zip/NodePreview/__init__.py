#
#     This file is part of NodePreview.
#     Copyright (C) 2021 Simon Wendsche
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.

import bpy
from bpy.types import AddonPreferences
from bpy.props import FloatProperty, FloatVectorProperty, IntProperty, EnumProperty, BoolProperty
from bpy.utils import register_class, unregister_class

from os.path import basename, dirname


addon_name = basename(dirname(__file__))
THUMB_CHANNEL_COUNT = 4
addon_keymaps = []

bl_info = {
    "name": "Node Preview",
    "author": "Simon Wendsche (B.Y.O.B.)",
    "version": (1, 2),
    "blender": (2, 80, 0),
    "category": "Node",
    "location": "Shader Node Editor",
    "description": "Displays rendered thumbnails above shader nodes",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
}


class UnsupportedNodeException(Exception):
    pass


def is_group_node(node):
    return hasattr(node, "node_tree") and (isinstance(node.node_tree, bpy.types.ShaderNodeTree) or node.node_tree is None)


def force_node_editor_draw():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == "NODE_EDITOR":
                for region in area.regions:
                    if region.type == "WINDOW":
                        region.tag_redraw()


def needs_linking(image):
    return image.packed_file or image.source == "GENERATED"


class BACKGROUND_PATTERNS:
    CHECKER = "CHECKER"
    WHITE = "WHITE"


BG_COLOR_DESC = ("Visible when parts of a shader are transparent. Note that very dark or saturated background "
                 "colors can produce misleading results for thumbnails of colored transparent shaders")


class NodePreviewAddonPreferences(AddonPreferences):
    # Must be the addon directory name
    # (by default "NodePreview", but a user/dev might change the folder name)
    bl_idname = addon_name

    thumb_scale: FloatProperty(name="Thumbnail Scale", default=50, min=1, max=100,
                               subtype="PERCENTAGE")

    thumb_resolution: IntProperty(name="Thumbnail Resolution", default=150, min=50, soft_max=300, max=500,
                                  description="Higher resolutions preserve fine detail in textures better, but lead to slower updates")

    background_pattern_items = [
        (BACKGROUND_PATTERNS.CHECKER, "Checkerboard Pattern", "", 0),
        (BACKGROUND_PATTERNS.WHITE, "Solid Color", "", 1),
    ]
    background_pattern: EnumProperty(name="Background", items=background_pattern_items, default="CHECKER",
                                     description="The background pattern is visible when parts of a shader are transparent/transmissive")

    background_color_1: FloatVectorProperty(name="Background Color", default=(0.994, 0.994, 0.994), min=0, max=1, subtype="COLOR",
                                            description=BG_COLOR_DESC)
    background_color_2: FloatVectorProperty(name="Background Color", default=(0.8086, 0.8086, 0.8086), min=0, max=1, subtype="COLOR",
                                            description=BG_COLOR_DESC)

    show_help: BoolProperty(name="Show Help Messages", default=True,
                            description="Show the following help messages:\n"
                                        "- Procedural texture scale can be ignored with Ctrl+Shift+I (shown if texture scale is so large\n"
                                        "  that the texture is no longer recognizable, or if texture scale is driven by another texture")

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.prop(self, "thumb_scale")
        row.prop(self, "thumb_resolution")

        row = layout.row()
        row.label(text="Background:")
        row.prop(self, "background_pattern", expand=True)

        using_checker_pattern = self.background_pattern == BACKGROUND_PATTERNS.CHECKER
        row = layout.row()
        row.label(text="")
        if using_checker_pattern:
            row.label(text="")
        row.prop(self, "background_color_1", text=("Color 1" if using_checker_pattern else "Color"))
        if using_checker_pattern:
            row.prop(self, "background_color_2", text="Color 2")

        layout.prop(self, "show_help")


def get_ignore_scale(node):
    return node.get("nodepreview_ignore_scale", False)

def set_ignore_scale(node, value):
    node["nodepreview_ignore_scale"] = value


class NODEPREVIEW_OT_toggle_ignore_scale(bpy.types.Operator):
    bl_idname = "nodepreview.toggle_ignore_scale"
    bl_label = "Toggle Ignore Scale"
    bl_description = "Toggle wether to ignore procedural texture scale of this node when rendering the node preview"
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space.type == "NODE_EDITOR" and space.node_tree

    def invoke(self, context, event):
        space = context.space_data
        node_tree = space.node_tree

        for node in node_tree.nodes:
            if node.select:
                set_ignore_scale(node, not get_ignore_scale(node))

        force_node_editor_draw()
        return {"FINISHED"}


def register():
    register_class(NodePreviewAddonPreferences)

    if bpy.app.background:
        from . import background
    else:
        from .display import display_register
        display_register()

        register_class(NODEPREVIEW_OT_toggle_ignore_scale)

        # Register keymap
        wm = bpy.context.window_manager
        keymap = wm.keyconfigs.addon.keymaps.new(name="Node Editor", space_type="NODE_EDITOR")

        keymap_item = keymap.keymap_items.new(NODEPREVIEW_OT_toggle_ignore_scale.bl_idname, "I", "PRESS", ctrl=True,
                                              shift=True)
        addon_keymaps.append((keymap, keymap_item))


def unregister():
    unregister_class(NodePreviewAddonPreferences)

    if not bpy.app.background:
        from .display import display_unregister
        display_unregister()

        unregister_class(NODEPREVIEW_OT_toggle_ignore_scale)

        # Unregister keymaps
        for keymap, keymap_item in addon_keymaps:
            keymap.keymap_items.remove(keymap_item)
        addon_keymaps.clear()
